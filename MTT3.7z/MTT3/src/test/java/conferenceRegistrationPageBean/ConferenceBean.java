package conferenceRegistrationPageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceBean {
	
	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pfFname;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement pfLname;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement pfEmail;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement pfPhone;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[5]/td[2]")
	@CacheLookup
	WebElement pfNoOfPeopleAttending;
	
	@FindBy(name="Address")
	@CacheLookup
	WebElement pfAddress;
	
	@FindBy(name="Address2")
	@CacheLookup
	WebElement pfAddress2;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement pfcity;
	
	@FindBy(how=How.NAME, using="state")
	@CacheLookup
	WebElement pfstate;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input")
	@CacheLookup
	WebElement pfMembershipStatus;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[13]/td[2]/input")
	@CacheLookup
	WebElement pfMembershipStatus2;
	
	@FindBy(tagName="a")
	@CacheLookup
	WebElement pfNext;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement pfCardHolderName;
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement pfDebit;
	
	@FindBy(name="cvv")
	@CacheLookup
	WebElement pfCvv;
	
	@FindBy(name="month")
	@CacheLookup
	WebElement pfMonth;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement pfYear;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement pfButton;

	
	
	public WebElement getPfFname() {
		return pfFname;
	}

	public void setPfFname(String sFname) {
		pfFname.sendKeys(sFname);
	}

	public WebElement getPfLname() {
		return pfLname;
	}

	public void setPfLname(String sLname) {
		pfLname.sendKeys(sLname);
	}

	public WebElement getPfEmail() {
		return pfEmail;
	}

	public void setPfEmail(String sEmail) {
		pfEmail.sendKeys(sEmail);
	}

	public WebElement getPfPhone() {
		return pfPhone;
	}

	public void setPfPhone(String sPhone) {
		pfPhone.sendKeys(sPhone);
	}

	public WebElement getPfNoOfPeopleAttending() {
		return pfNoOfPeopleAttending;
	}
//
	public void setPfNoOfPeopleAttending(String sNoOfPeopleAttending) {
		Select s=new Select(pfNoOfPeopleAttending);
		s.selectByVisibleText(sNoOfPeopleAttending);
	}

	public WebElement getPfAddress() {
		return pfAddress;
	}

	public void setPfAddress(String sAddress) {
		pfAddress.sendKeys(sAddress);
	}

	public WebElement getPfAddress2() {
		return pfAddress2;
	}

	public void setPfAddress2(String sAddress2) {
		pfAddress2.sendKeys(sAddress2);
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public void setPfcity(String scity) {
		Select drpCity = new Select(pfcity);
		drpCity.selectByVisibleText(scity);
	}

	public WebElement getPfstate() {
		return pfstate;
	}

	public void setPfstate(String sstate) {
		Select drpState = new Select(pfstate);
		drpState.selectByVisibleText(sstate);
	}

	public WebElement getPfMembershipStatus() {
		return pfMembershipStatus;
	}

	public void setPfMembershipStatus() {
		pfMembershipStatus.click();
	}
	
	

	public WebElement getPfMembershipStatus2() {
		return pfMembershipStatus2;
	}

	public void setPfMembershipStatus2() {
		pfMembershipStatus2.click();
	}

	public WebElement getPfNext() {
		return pfNext;
	}
//
	public void setPfNext() {
		pfNext.click();
	}

	public WebElement getPfCardHolderName() {
		return pfCardHolderName;
	}

	public void setPfCardHolderName(String sCardHolderName) {
		pfCardHolderName.sendKeys(sCardHolderName);
	}

	public WebElement getPfDebit() {
		return pfDebit;
	}

	public void setPfDebit(String sDebit) {
		pfDebit.sendKeys(sDebit);
	}

	public WebElement getPfCvv() {
		return pfCvv;
	}

	public void setPfCvv(String sCvv) {
		pfCvv.sendKeys(sCvv);
	}

	public WebElement getPfMonth() {
		return pfMonth;
	}

	public void setPfMonth(String sMonth) {
		pfMonth.sendKeys(sMonth);
	}

	public WebElement getPfYear() {
		return pfYear;
	}

	public void setPfYear(String sYear) {
		pfYear.sendKeys(sYear);
	}

	public WebElement getPfButton() {
		return pfButton;
	}

	public void setPfButton() {
		pfButton.click();
	}

	public ConferenceBean(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	

}
