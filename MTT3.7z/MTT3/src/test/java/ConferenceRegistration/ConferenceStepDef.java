package ConferenceRegistration;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import conferenceRegistrationPageBean.ConferenceBean;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceStepDef {
	
	
	WebDriver driver;
	ConferenceBean obj;
	@Given("^User is on conference registration page$")
	public void user_is_on_conference_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/RAHCHAUH/Desktop/Chrome/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///C:/Users/RAHCHAUH/Desktop/Example/Set%20B/ConferenceRegistartion.html");
		obj=new ConferenceBean(driver);
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Conference Registartion"))
			System.out.println("***");
		else
			System.out.println("Title not matched");
		driver.manage().timeouts().implicitlyWait(70,TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
	    obj.setPfFname("");
	    Thread.sleep(500);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		 obj.setPfNext();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(500);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	    
	}

	@When("^user leaves last Name blank$")
	public void user_leaves_last_Name_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("");
		 Thread.sleep(500);
	}

	@When("^clicks the next button$")
	public void clicks_the_next_button() throws Throwable {
		 obj.setPfNext();
	}

	@When("^user leaves email blank$")
	public void user_leaves_email_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("");
		 Thread.sleep(500);
	}

	@When("^user enters incorrect email format and clicks the next button$")
	public void user_enters_incorrect_email_format_and_clicks_the_next_button() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahulcom");
		 Thread.sleep(500);
		 obj.setPfNext();
	}

	@When("^user leaves contact no blank$")
	public void user_leaves_contact_no_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
	}

	@When("^user leaves MobileNo blank and clicks the next button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_next_button(DataTable arg1) throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("");
		 Thread.sleep(500);
		 obj.setPfNext();
	}

	@When("^user enters incorrect contactNo format and clicks the next button$")
	public void user_enters_incorrect_contactNo_format_and_clicks_the_next_button(DataTable arg1) throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		
		List<String> objList = arg1.asList(String.class);
		//obj.setPfPhone(objList);	
		obj.setPfNext();
		
		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
			System.out.println("***** Matched" + objList.get(i) + "*****");
			}
			else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
			}
		}
	}
	
	

	@When("^user doesnot select number of people attending$")
	public void user_doesnot_select_number_of_people_attending() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		
		 
	}

	@When("^user leaves Building Name and Room no blank$")
	public void user_leaves_Building_Name_and_Room_no_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("");
		 
	}

	@When("^user leaves Area name blank$")
	public void user_leaves_Area_name_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("");
	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Select City");Thread.sleep(500);
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Select state");
	}

	@When("^user doesnot select membership status$")
	public void user_doesnot_select_membership_status() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Maharashtra");Thread.sleep(500);
		 obj.setPfNext();
		 
		 
	}

	@When("^User enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Maharashtra");Thread.sleep(500);
		 obj.setPfMembershipStatus2();
	}

	@Then("^navigate to payment details page$")
	public void navigate_to_payment_details_page() throws Throwable {
		driver.navigate().to("file:///C:/Users/RAHCHAUH/Desktop/Example/Set%20B/PaymentDetails.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@Given("^User is on payment details page$")
	public void user_is_on_payment_details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/RAHCHAUH/Desktop/Chrome/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///C:/Users/RAHCHAUH/Desktop/Example/Set%20B/PaymentDetails.html");
		obj=new ConferenceBean(driver);
	}

	@When("^user leaves Card holder name blank$")
	public void user_leaves_Card_holder_name_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Maharashtra");Thread.sleep(500);
		 obj.setPfMembershipStatus2();
		 obj.setPfCardHolderName("");
	}

	@When("^clicks the make payment button$")
	public void clicks_the_make_payment_button() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Maharashtra");Thread.sleep(500);
		 obj.setPfMembershipStatus2();
		// obj.setPfCardHolderName("RahulChauhan");
		 obj.setPfButton();
	}

	@When("^user leaves Debit card number blank$")
	public void user_leaves_Debit_card_number_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Maharashtra");Thread.sleep(500);
		 obj.setPfMembershipStatus2();
		obj.setPfCardHolderName("RahulChauhan");
		obj.setPfDebit("");
	}

	@When("^user leaves Card expiration month blank$")
	public void user_leaves_Card_expiration_month_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Maharashtra");Thread.sleep(500);
		 obj.setPfMembershipStatus2();
		 obj.setPfCardHolderName("RahulChauhan");
		 obj.setPfDebit("488549662");
		 obj.setPfMonth("");
	}

	@When("^user leaves Card expiration year blank$")
	public void user_leaves_Card_expiration_year_blank() throws Throwable {
		obj.setPfFname("Rahul");
		 Thread.sleep(500);
		 obj.setPfLname("Chauhan");
		 Thread.sleep(500);
		 obj.setPfEmail("rahul@gmail.com");
		 Thread.sleep(500);
		 obj.setPfPhone("7500349800"); Thread.sleep(500);
		// obj.setPfNoOfPeopleAttending("2"); Thread.sleep(500);
		 obj.setPfAddress("Devi indrayani");Thread.sleep(500);
		 obj.setPfAddress2("Talwade");Thread.sleep(500);
		 obj.setPfcity("Pune");Thread.sleep(500);
		 obj.setPfstate("Maharashtra");Thread.sleep(500);
		 obj.setPfMembershipStatus2();
		 obj.setPfCardHolderName("RahulChauhan");
		 obj.setPfDebit("488549662");
		 obj.setPfMonth("Jan");
		 obj.setPfYear("");
	}

	@When("^User enters all valid payment data$")
	public void user_enters_all_valid_payment_data() throws Throwable {
	    
	}

}
